package com.onlinebankingsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.onlinebankingsystem.model.Profile;

@Repository
public interface ProfileRepository extends JpaRepository<Profile, Long> {
	@Query(value="select profile from Profile profile where profile.user.id=:id")
	Profile findProfileByuserId(Long id);

}
