package com.onlinebankingsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.onlinebankingsystem.model.Account;
@Repository
public interface AccountRepository extends JpaRepository<Account, Long>{
	@Query(value="select account from Account account where account.user.id=:id")
	Account findAccountByuserId(Long id);
	
	
	

}
