package com.onlinebankingsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.onlinebankingsystem.model.User;
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	@Query(value="select user from User user where user.password=:password and user.email=:username ")
	User findUserByUserNameAndPassword(String username , String password);

	boolean existsByEmail(String email);
}
