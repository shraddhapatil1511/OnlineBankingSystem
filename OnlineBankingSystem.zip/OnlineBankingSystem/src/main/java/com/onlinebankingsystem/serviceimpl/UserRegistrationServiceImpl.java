package com.onlinebankingsystem.serviceimpl;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinebankingsystem.dto.UserRegistration;
import com.onlinebankingsystem.exception.AccountNotFoundException;
import com.onlinebankingsystem.exception.DuplicateEmailException;
import com.onlinebankingsystem.exception.InactiveAccountException;
import com.onlinebankingsystem.exception.InsufficientBalanceException;
import com.onlinebankingsystem.exception.InvalidCredentialsException;
import com.onlinebankingsystem.exception.RegistrationException;
import com.onlinebankingsystem.exception.TransactionSystemException;
import com.onlinebankingsystem.exception.UserNotFoundException;
import com.onlinebankingsystem.model.Account;
import com.onlinebankingsystem.model.Profile;
import com.onlinebankingsystem.model.User;
import com.onlinebankingsystem.repository.AccountRepository;
import com.onlinebankingsystem.repository.ProfileRepository;
import com.onlinebankingsystem.repository.UserRepository;
import com.onlinebankingsystem.service.UserService;
import com.onlinebankingsystem.utils.Constants;

@Service
public class UserRegistrationServiceImpl implements UserService {
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ProfileRepository profileRepository;
	
	@Autowired
	AccountRepository accountRepository;
	

	@Override
	public User registerUser(UserRegistration userRegistration) throws TransactionSystemException, DuplicateEmailException  {
		if (userRepository.existsByEmail(userRegistration.getEmail())) {
            throw new DuplicateEmailException(Constants.alreadyExistEmail);
		}
		
		User user=new User();
		user.setCreated_at(LocalDateTime.now());
		user.setEmail(userRegistration.getEmail());
		user.setPassword(userRegistration.getPassword());
		User userSave=userRepository.save(user);
		if(userSave==null) {
			throw new TransactionSystemException(Constants.USER_NOT_SAVED);
		}
		
		Profile profile=new Profile();
		profile.setAddress(userRegistration.getAddress());
		profile.setFirstName(userRegistration.getFirstName());
		profile.setLastName(userRegistration.getLastName());
		profile.setPhoneNumber(userRegistration.getPhoneNumber());
		profile.setUser(userSave);
		
		profileRepository.save(profile);
		
		//Saving account details
		Account account=new Account();
		account.setBalance(BigDecimal.ZERO);
		account.setCreateAt(LocalDateTime.now());
		account.setStatus(true);
		account.setUser(userSave);
		
		accountRepository.save(account);
		
		
	return user;


	}

	@Override
	public String validateUser(String userName, String password) throws InvalidCredentialsException {
		
		User user=userRepository.findUserByUserNameAndPassword(userName,password);
		
		if(user==null) {
			throw new InvalidCredentialsException(Constants.INVALID_USERNAME_PASSWORD);
		}
		return Constants.LOGIN_SUCCESSFULLY;

			
		}
		
	

	@Override
	public String getBalanceByuserId(Long userId) throws InsufficientBalanceException, AccountNotFoundException, InactiveAccountException {
		
		
		Account account=accountRepository.findAccountByuserId(userId);
		if(account==null) {
			throw new AccountNotFoundException(Constants.ACCOUNT_NOT_FOUND);
		}
		if(account.getBalance()==null) {
			throw new InsufficientBalanceException(Constants.BALANCE_NOT_FOUND);
		}
		 
		if(account.getStatus()!=true) {
			throw new InactiveAccountException(Constants.ACCOUNT_IS_IN_ACTIVE);
		}
		String balance = Constants.AVAILABEL_BALANCE+ account.getBalance().toString();
		return  balance;
		
		}

        }

	


