package com.onlinebankingsystem.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinebankingsystem.dto.ProfileUpdateDto;
import com.onlinebankingsystem.exception.AccountNotFoundException;
import com.onlinebankingsystem.exception.ProfileNotFoundException;
import com.onlinebankingsystem.exception.UserNotFoundException;
import com.onlinebankingsystem.model.Account;
import com.onlinebankingsystem.model.Profile;
import com.onlinebankingsystem.model.User;
import com.onlinebankingsystem.repository.AccountRepository;
import com.onlinebankingsystem.repository.ProfileRepository;
import com.onlinebankingsystem.repository.UserRepository;
import com.onlinebankingsystem.service.ProfileManagerService;
import com.onlinebankingsystem.utils.Constants;
@Service
public class ProfileManagerServiceImpl implements ProfileManagerService{
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ProfileRepository profileRepository;
	
	@Autowired
	AccountRepository accountRepository;

	@Override
	public String updateData(ProfileUpdateDto profileUpdateDto) throws ProfileNotFoundException, UserNotFoundException {
		User user=userRepository.findById(profileUpdateDto.getUserId())
				.orElseThrow(()-> new UserNotFoundException(Constants.USER_NOT_FOUND));
		
		
		if(profileUpdateDto.getPassword()!=null) {
		user.setPassword(profileUpdateDto.getPassword());
		}
		
		if(profileUpdateDto.getEmail()!=null) {
			user.setEmail(profileUpdateDto.getEmail());
		}
		userRepository.save(user);
		
		Profile profile=profileRepository
				.findProfileByuserId(user.getUserId());
		if(profile==null) {
			throw new ProfileNotFoundException(Constants.PROFILE_NOT_FOUND);
		}
		if(profileUpdateDto.getAddress()!=null) {
		profile.setAddress(profileUpdateDto.getAddress());
		}
		if(profileUpdateDto.getFirstName()!=null) {
		profile.setFirstName(profileUpdateDto.getFirstName());
		}
		if(profileUpdateDto.getLastName()!=null) {
		profile.setLastName(profileUpdateDto.getLastName());
		}
		if(profileUpdateDto.getPhoneNumber()!=null) {
		profile.setPhoneNumber(profileUpdateDto.getPhoneNumber());
		}
		profileRepository.save(profile);
		
		
		return Constants.PROFILE_UPDATE_SUCCESS_MESSAGE;
		
	


		}

	@Override
	public void closeAccount(Long accountId) throws AccountNotFoundException {
		
		Account account=accountRepository.findById(accountId).orElseThrow(()-> new AccountNotFoundException(Constants.ACCOUNT_NOT_FOUND));
		account.setStatus(false);
		accountRepository.save(account);
		

		
		
	}

}
