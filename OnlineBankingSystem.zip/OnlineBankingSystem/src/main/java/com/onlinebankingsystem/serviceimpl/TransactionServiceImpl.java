package com.onlinebankingsystem.serviceimpl;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinebankingsystem.dto.TransactionRequest;
import com.onlinebankingsystem.dto.TransferRequest;
import com.onlinebankingsystem.exception.AccountNotFoundException;
import com.onlinebankingsystem.exception.InactiveAccountException;
import com.onlinebankingsystem.exception.InsufficientBalanceException;
import com.onlinebankingsystem.exception.UserNotFoundException;
import com.onlinebankingsystem.model.Account;
import com.onlinebankingsystem.model.Transaction;
import com.onlinebankingsystem.model.User;
import com.onlinebankingsystem.repository.AccountRepository;
import com.onlinebankingsystem.repository.ProfileRepository;
import com.onlinebankingsystem.repository.TransactionRepository;
import com.onlinebankingsystem.repository.UserRepository;
import com.onlinebankingsystem.service.TransactionService;
import com.onlinebankingsystem.utils.Constants;
@Service
public class TransactionServiceImpl implements TransactionService {
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ProfileRepository profileRepository;
	
	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	TransactionRepository transactionRepository;
	
	@Override
	public void deposite(TransactionRequest transactionRequest) throws InactiveAccountException, UserNotFoundException, AccountNotFoundException {
      Account account =getAccountById(transactionRequest.getAccountId());
		
		if(account.getStatus()!=true) {
			throw new InactiveAccountException(Constants.ACCOUNT_IS_IN_ACTIVE);
		}
		BigDecimal newBalance;
		if(account.getBalance()!=null) {
			newBalance=account.getBalance().add(transactionRequest.getAmount());
		}else {
			newBalance=transactionRequest.getAmount();
		}
		
		account.setBalance(newBalance);
		accountRepository.save(account);
		createTransaction(transactionRequest.getUserId(), account, Constants.DEPOSITE, transactionRequest.getAmount());

	}

		
	@Override
	public void withdraw(TransactionRequest transactionRequest) throws InactiveAccountException, InsufficientBalanceException, UserNotFoundException, AccountNotFoundException {
		Account account =getAccountById(transactionRequest.getAccountId());
		if(account.getStatus()!=true) {
		
			throw new InactiveAccountException(Constants.ACCOUNT_IS_IN_ACTIVE);
		}
		BigDecimal newBalance;
		if(account.getBalance()!=null) {
			newBalance=account.getBalance().subtract(transactionRequest.getAmount());
		}else {
			newBalance=transactionRequest.getAmount();
		}
		
		
		if(newBalance.compareTo(BigDecimal.ZERO)<0) {
			throw new InsufficientBalanceException(Constants.INSUFFICIENT_BALANCE);
		}
		
		account.setBalance(newBalance);
		accountRepository.save(account);
		
		createTransaction(transactionRequest.getUserId(), account, Constants.WITHDEAW, transactionRequest.getAmount());
		

	}

	@Override
	public void Transfer(TransferRequest transferRequest) throws InactiveAccountException, InsufficientBalanceException, UserNotFoundException, AccountNotFoundException {
		Account sourceAccount=getAccountById(transferRequest.getSourceAccountId());
		Account targetAccount=getAccountById(transferRequest.getTargetAccountId());
		
		
		if(sourceAccount.getStatus()!=true) {
			throw new InactiveAccountException(Constants.ACCOUNT_IS_IN_ACTIVE);
		}
		
		if(targetAccount.getStatus()!=true) {
			throw new InactiveAccountException(Constants.ACCOUNT_IS_IN_ACTIVE);
		}
		
		BigDecimal sourceBalance;
		
		BigDecimal targetBalance;
		if(sourceAccount.getBalance()!=null) {
			sourceBalance=sourceAccount.getBalance();
		}else {
			sourceBalance=BigDecimal.ZERO;
		}
		
		if(targetAccount.getBalance()!=null) {
			targetBalance=targetAccount.getBalance();
			
		}else {
			targetBalance=BigDecimal.ZERO;
		}
		
		BigDecimal amount =transferRequest.getAmount();
		if(sourceBalance.compareTo(amount)<0) {
			throw new InsufficientBalanceException(Constants.INSUFFICIENT_BALANCE);
		}
		
		
		sourceAccount.setBalance(sourceBalance.subtract(amount));
		targetAccount.setBalance(targetBalance.add(amount));
		
		accountRepository.save(targetAccount);
		accountRepository.save(sourceAccount);
	
		createTransaction(targetAccount.getUser().getUserId(), targetAccount, Constants.Transfer_Credit, amount);
		
		createTransaction(sourceAccount.getUser().getUserId(), sourceAccount, Constants.Transfer_Debit, amount);

		}

	
private Account getAccountById(Long accountId) throws AccountNotFoundException {
		
		return accountRepository.findById(accountId).orElseThrow(()-> new AccountNotFoundException(Constants.ACCOUNT_NOT_FOUND+accountId));
 
	}
	
	private User getUserById(Long userId) throws UserNotFoundException {
		
		 return userRepository.findById(userId).orElseThrow(()-> new UserNotFoundException(Constants.USER_NOT_FOUND+userId));
	}


  private void createTransaction(Long userId, Account account, String transactionType, BigDecimal amount) throws UserNotFoundException {
	
	  Transaction transaction= new Transaction();
		User user=getUserById(userId);
		transaction.setUser(user);
		transaction.setAccount(account);
		transaction.setAmount(amount);
		transaction.setTransactionType(transactionType);
		transaction.setTimeStamp(LocalDateTime.now());
		transactionRepository.save(transaction);
		

	
		
		
	}





	

}
