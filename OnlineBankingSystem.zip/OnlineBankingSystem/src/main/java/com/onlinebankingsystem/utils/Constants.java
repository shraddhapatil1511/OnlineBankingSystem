package com.onlinebankingsystem.utils;

public class Constants {
	public static final String PROFILE_UPDATE_SUCCESS_MESSAGE = "User Profile Updated SuccesssFully";
	 public static final String ACCOUNT_IS_IN_ACTIVE ="Your Account Is Currenty In-Active Transaction Can Not Be Performed At This Time ";
	 public static final String DEPOSITE = "Deposit";
	 public static final String INSUFFICIENT_BALANCE="Apologies , there is insufficient balance in your account to complete this transaction";
	 public static final String WITHDEAW="Withdraw";
	 public static final String Transfer_Credit = "Transfer(Credit)";
	 public static final String Transfer_Debit= "Transfer(Debit)";
	 public static final String ACCOUNT_NOT_FOUND= "Account Not Found: ";
	 public static final String USER_NOT_FOUND= "User Not Found: ";
	 public static final String PROFILE_NOT_FOUND= "Profile Not Found: ";
	 public static final String INVALID_USERNAME_PASSWORD= "Invalid UserName Or Password";
	 public static final String LOGIN_SUCCESSFULLY= "Login Successfully";
	 public static final String AVAILABEL_BALANCE= "Availble Balance :";
	 public static final String ACCOUNT_CLOSE_SUCCESFULLY=  "Account Closed Succesfully";
	 public static final String TRANSACTION_COMPLTED ="Transaction is successfully completed";
	 public static final String TRANSFER="transsfer";
	 public static final String USER_REGISTER_SUCESSFULLY ="user Registered SucessFully";
	
	 public static final String BALANCE_NOT_FOUND ="account is new please Deposit Some Amount";
	 public static final String ERROR_OCCERED_WHILE_PROCESSING_REQUEST= "Error Occurred While Processing the request";
	 public static final String ERROR_OCCERED_WHILE_REGISTER_USER= "Error Occurred While Register user";
	 
	 public static final String TRANSACTION_NOT_FOUND_FOR_USER= "Transaction Not found for user with user Id: ";
	 
	 public static final String USER_NOT_SAVED= "Oops!Something went wrong while Saving Data ";
     public static final String Unexpected_ERROR = "An unexpected error occurred";
	 
	 public static final String	 OnlineBankingSystemBaseException="Error Occurred While Processing the request";
	 public static final String alreadyExistEmail= "Email address is already registered";
	 public Constants() {
	
	}


}
