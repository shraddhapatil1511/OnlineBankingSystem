package com.onlinebankingsystem.exception;

public class ProfileNotFoundException extends OnlineBankingSystemBaseException {
	
	private static final long serialVersionUID = 1L;

	public ProfileNotFoundException(String massage) {
		super(massage);
	}


}
