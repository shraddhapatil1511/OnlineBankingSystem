package com.onlinebankingsystem.exception;

public class TransactionNotFoundException extends OnlineBankingSystemBaseException{
	
	private static final long serialVersionUID = 1L;

	public TransactionNotFoundException(String massage) {
		super(massage);
	}



}
