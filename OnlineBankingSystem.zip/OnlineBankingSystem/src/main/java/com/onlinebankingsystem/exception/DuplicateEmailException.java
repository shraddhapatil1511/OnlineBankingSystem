package com.onlinebankingsystem.exception;

public class DuplicateEmailException extends OnlineBankingSystemBaseException {

	
	public DuplicateEmailException(String message) {
		super(message);
		
	}

	private static final long serialVersionUID = 1L;

}
