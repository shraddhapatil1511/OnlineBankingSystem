package com.onlinebankingsystem.exception;

public class TransactionSystemException extends OnlineBankingSystemBaseException{
	private static final long serialVersionUID = 1L;
	public TransactionSystemException(String message) {
		super(message);
		
	}

	

	

}
