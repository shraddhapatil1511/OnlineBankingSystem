package com.onlinebankingsystem.exception;

public class AccountNotFoundException extends OnlineBankingSystemBaseException {
	
	private static final long serialVersionUID = 1L;
	public AccountNotFoundException(String message) {
		super(message);
	}


}
