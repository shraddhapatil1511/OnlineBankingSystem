package com.onlinebankingsystem.exception;

public class InactiveAccountException extends OnlineBankingSystemBaseException {

	
	private static final long serialVersionUID = 1L;

	public InactiveAccountException(String message) {
		 super(message);
	 }

}
