package com.onlinebankingsystem.exception;

public class UserNotFoundException extends OnlineBankingSystemBaseException{
	
	private static final long serialVersionUID = 1L;

	public UserNotFoundException(String massage) {
		super(massage);
	}


}
