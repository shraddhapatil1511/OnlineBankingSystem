package com.onlinebankingsystem.exception;

public class RegistrationException extends OnlineBankingSystemBaseException {
	
	private static final long serialVersionUID = 1L;

	public RegistrationException(String massage) {
		super(massage);
	}


}
