package com.onlinebankingsystem.exception;

public class InsufficientBalanceException extends OnlineBankingSystemBaseException {
	
	private static final long serialVersionUID = 1L;

	public InsufficientBalanceException(String message) {
		super(message);
		
	}


}
