package com.onlinebankingsystem.exception;

public class InvalidCredentialsException extends OnlineBankingSystemBaseException {
	
	private static final long serialVersionUID = 1L;

	public InvalidCredentialsException(String message) {
		super(message);
	}

	
	

}
