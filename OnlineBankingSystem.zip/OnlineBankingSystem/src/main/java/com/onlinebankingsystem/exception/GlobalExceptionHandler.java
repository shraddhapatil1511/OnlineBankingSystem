package com.onlinebankingsystem.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.onlinebankingsystem.dto.Response;
import com.onlinebankingsystem.utils.Constants;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(AccountNotFoundException.class)
	public ResponseEntity<Response> handleAccountNotFoundException(Throwable ex){
		
		
		 Response response = new Response();
	        response.setCode(HttpStatus.NOT_FOUND.value());
	        response.setMessage(ex.getMessage());
		
		return  ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	}
	@ExceptionHandler(InactiveAccountException.class)
	public ResponseEntity<Response> handleInactiveAccountException(Throwable ex){
		 Response response = new Response();
	        response.setCode(HttpStatus.FORBIDDEN.value());
	        response.setMessage(ex.getMessage());
		return  ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
	}
	
	@ExceptionHandler(InsufficientBalanceException.class)
	public ResponseEntity<Response> handleInsufficientBalanceException(Throwable ex){
		 Response response = new Response();
	        response.setCode(HttpStatus.BAD_REQUEST.value());
	        response.setMessage(ex.getMessage());
		
		return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
	}

	@ExceptionHandler(InvalidCredentialsException.class)
	public ResponseEntity<Response> handleInvalidCredentialException(Throwable ex){
		 Response response = new Response();
	        response.setCode(HttpStatus.UNAUTHORIZED.value());
	        response.setMessage(ex.getMessage());
		
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
	}
	@ExceptionHandler(ProfileNotFoundException.class)
	public ResponseEntity<Response> handleProfileNotFoundException(Throwable ex){
		
		Response response = new Response();
        response.setCode(HttpStatus.NOT_FOUND.value());
        response.setMessage(ex.getMessage());
	
		return  ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	}

	@ExceptionHandler(RegistrationException.class)
	public ResponseEntity<Response> handleRegistretionException(Throwable ex){
		Response response = new Response();
        response.setCode(HttpStatus.BAD_REQUEST.value());
        response.setMessage(ex.getMessage());
		
		return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
	}
	@ExceptionHandler(TransactionNotFoundException.class)
	public ResponseEntity<Response> handleTransactionNotFoundException(Throwable ex){
		
		Response response = new Response();
        response.setCode(HttpStatus.NOT_FOUND.value());
        response.setMessage(ex.getMessage());
		
		return  ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	}
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<Response> handleUserNotFoundException(Throwable ex){
		
		Response response = new Response();
        response.setCode(HttpStatus.NOT_FOUND.value());
        response.setMessage(ex.getMessage());
		return  ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	}
	
	@ExceptionHandler(TransactionSystemException.class)
	public ResponseEntity<Response> handleTransactionSystemException(Throwable ex){
		 Response response = new Response();
	        response.setCode(HttpStatus.BAD_REQUEST.value());
	        response.setMessage(ex.getMessage());
		
		return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
	}
		
		@ExceptionHandler(OnlineBankingSystemBaseException.class)
		public ResponseEntity<Response> handleOnlineBankingException(Throwable ex){
			Response response = new Response();
	        response.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
	        response.setMessage(ex.getMessage());
			return  ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		
	}
		@ExceptionHandler(DuplicateEmailException.class)
	    public ResponseEntity<Response> handleDuplicateEmailExceptionException(Exception ex) {
	        Response response = new Response();
	        response.setCode(HttpStatus.CONFLICT.value()); 
	        response.setMessage(ex.getMessage()); 
	        return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
		}
      
		 @ExceptionHandler(Exception.class)
		    public ResponseEntity<Response> handleException(Exception ex) {
		        Response response = new Response();
		        response.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value()); // Default to internal server error for unhandled exceptions
		        response.setMessage(Constants.Unexpected_ERROR); // Set a generic error message
		        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		    }
}


