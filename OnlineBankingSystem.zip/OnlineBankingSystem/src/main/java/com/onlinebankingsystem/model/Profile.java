package com.onlinebankingsystem.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="profiles")
public class Profile {
 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long profileId;
	@OneToOne
	@JoinColumn(name="user_id")
	private User user;
	@Column(name="firstName")
	private String firstName;
	@Column(name="lastName")
	private String lastName;
	@Column(name="address")
	private String address;
	@Column(name="phoneNumber")
	private String phoneNumber;
 
	public Long getProfileId() {
		return profileId;
	}
 
	public void setProfileId(Long profileId) {
		this.profileId = profileId;
	}
 
	public User getUser() {
		return user;
	}
 
	public void setUser(User user) {
		this.user = user;
	}
 
	public String getFirstName() {
		return firstName;
	}
 
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
 
	public String getLastName() {
		return lastName;
	}
 
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
 
	public String getAddress() {
		return address;
	}
 
	public void setAddress(String address) {
		this.address = address;
	}
 
	public String getPhoneNumber() {
		return phoneNumber;
	}
 
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
 
	public Profile(Long profileId, User user, String firstName, String lastName, String address, String phoneNumber) {
		super();
		this.profileId = profileId;
		this.user = user;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.phoneNumber = phoneNumber;
	}
 
	public Profile() {
		super();
		// TODO Auto-generated constructor stub
	}

}
