package com.onlinebankingsystem.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
 
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
 
@Entity
@Table(name="accounts")
public class Account {
 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long accountId;
	@OneToOne
	@JoinColumn(name="user_id")
	private User user;
	@Column(name="balance")
	private BigDecimal balance;
	//active or in-active
	@Column(name="status")
	private boolean status;
	@Column(name="create_at")
	private LocalDateTime createAt;
 
	public Long getAccountId() {
		return accountId;
	}
 
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
 
	public User getUser() {
		return user;
	}
 
	public void setUser(User user) {
		this.user = user;
	}
 
	public BigDecimal getBalance() {
		return balance;
	}
 
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
 
	public boolean getStatus() {
		return status;
	}
 
	public void setStatus(boolean status) {
		this.status = status;
	}
 
	public LocalDateTime getCreateAt() {
		return createAt;
	}
 
	public void setCreateAt(LocalDateTime createAt) {
		this.createAt = createAt;
	}
 
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
 
	public Account(Long accountId, User user, BigDecimal balance, boolean status, LocalDateTime createAt) {
		super();
		this.accountId = accountId;
		this.user = user;
		this.balance = balance;
		this.status = status;
		this.createAt = createAt;
	}

}