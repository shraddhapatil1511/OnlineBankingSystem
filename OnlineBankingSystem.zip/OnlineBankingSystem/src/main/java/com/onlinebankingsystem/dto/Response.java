package com.onlinebankingsystem.dto;

public class Response {
	   // Response Data 
	    private String message; //custom Message // Handled Exception 
	    private Integer code;
		public Integer getCode() {
			return code;
		}
		public void setCode(Integer code) {
			this.code = code;
		}
		
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
	    
	    
}

