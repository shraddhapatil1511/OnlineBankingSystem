package com.onlinebankingsystem.dto;

import java.math.BigDecimal;

public class TransactionResponseDto {
	 
		private Long userId;
		private Long accountId;
		private	String TransactioType;
		private BigDecimal amount;
		
		public Long getUserId() {
			return userId;
		}
		public void setUserId(Long userId) {
			this.userId = userId;
		}
		public Long getAccountId() {
			return accountId;
		}
		public void setAccountId(Long accountId) {
			this.accountId = accountId;
		}
		public String getTransactioType() {
			return TransactioType;
		}
		public void setTransactioType(String transactioType) {
			TransactioType = transactioType;
		}
		public BigDecimal getAmount() {
			return amount;
		}
		public void setAmount(BigDecimal amount) {
			this.amount = amount;
		}
		
		}


