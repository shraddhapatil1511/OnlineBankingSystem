package com.onlinebankingsystem.service;

import com.onlinebankingsystem.dto.UserRegistration;
import com.onlinebankingsystem.exception.AccountNotFoundException;
import com.onlinebankingsystem.exception.DuplicateEmailException;
import com.onlinebankingsystem.exception.InactiveAccountException;
import com.onlinebankingsystem.exception.InsufficientBalanceException;
import com.onlinebankingsystem.exception.InvalidCredentialsException;
import com.onlinebankingsystem.exception.RegistrationException;
import com.onlinebankingsystem.exception.TransactionSystemException;
import com.onlinebankingsystem.exception.UserNotFoundException;
import com.onlinebankingsystem.model.User;

public interface UserService {

	User registerUser(UserRegistration userRegistration) throws  TransactionSystemException, DuplicateEmailException;

	String validateUser(String userName, String password) throws InvalidCredentialsException;

	String getBalanceByuserId(Long userId) throws InsufficientBalanceException, AccountNotFoundException, InactiveAccountException;

}
