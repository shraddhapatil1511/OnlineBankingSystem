package com.onlinebankingsystem.service;

import com.onlinebankingsystem.dto.ProfileUpdateDto;
import com.onlinebankingsystem.exception.AccountNotFoundException;
import com.onlinebankingsystem.exception.ProfileNotFoundException;
import com.onlinebankingsystem.exception.UserNotFoundException;

public interface ProfileManagerService {

	String updateData(ProfileUpdateDto profileUpdateDto ) throws ProfileNotFoundException, UserNotFoundException;

	public void closeAccount(Long accountId) throws AccountNotFoundException;

}
