package com.onlinebankingsystem.service;

import com.onlinebankingsystem.dto.TransactionRequest;
import com.onlinebankingsystem.dto.TransferRequest;
import com.onlinebankingsystem.exception.AccountNotFoundException;
import com.onlinebankingsystem.exception.InactiveAccountException;
import com.onlinebankingsystem.exception.InsufficientBalanceException;
import com.onlinebankingsystem.exception.UserNotFoundException;

public interface TransactionService {

	public void withdraw(TransactionRequest transactionRequest) throws InactiveAccountException, InsufficientBalanceException, UserNotFoundException, AccountNotFoundException;

	public void deposite(TransactionRequest transactionRequest) throws InactiveAccountException, UserNotFoundException, AccountNotFoundException;

	public void Transfer(TransferRequest transferRequest) throws InactiveAccountException, InsufficientBalanceException, UserNotFoundException, AccountNotFoundException;

}
