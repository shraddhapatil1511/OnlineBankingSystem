package com.onlinebankingsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onlinebankingsystem.dto.ProfileUpdateDto;
import com.onlinebankingsystem.dto.Response;
import com.onlinebankingsystem.exception.AccountNotFoundException;
import com.onlinebankingsystem.exception.ProfileNotFoundException;
import com.onlinebankingsystem.exception.UserNotFoundException;
import com.onlinebankingsystem.service.ProfileManagerService;
import com.onlinebankingsystem.utils.Constants;
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/profile")
public class ProfileManagerController {
    
	@Autowired(required = true)
	ProfileManagerService profileManagerService;
    
    @PostMapping("/update")
    public ResponseEntity<Response> validateUser(@RequestBody ProfileUpdateDto profileUpdateDto) throws UserNotFoundException, ProfileNotFoundException{
    	Response response=new Response();
    	profileManagerService.updateData(profileUpdateDto);
    	response.setMessage(Constants.PROFILE_UPDATE_SUCCESS_MESSAGE);
    	response.setCode(HttpStatus.OK.value());
        return ResponseEntity.ok(response);

	}
    
    @PostMapping("/closeAccount/{accountId}")
    public ResponseEntity<Response> closeAccount(@PathVariable Long accountId) throws AccountNotFoundException{
    	Response response=new Response();
    	profileManagerService.closeAccount(accountId);
    	response.setMessage(Constants.ACCOUNT_CLOSE_SUCCESFULLY);
		response.setCode(HttpStatus.OK.value());
        return ResponseEntity.ok(response);

   
    }
    
    
}
