package com.onlinebankingsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onlinebankingsystem.dto.Response;
import com.onlinebankingsystem.dto.TransactionRequest;
import com.onlinebankingsystem.dto.TransferRequest;
import com.onlinebankingsystem.exception.AccountNotFoundException;
import com.onlinebankingsystem.exception.InactiveAccountException;
import com.onlinebankingsystem.exception.InsufficientBalanceException;
import com.onlinebankingsystem.exception.UserNotFoundException;
import com.onlinebankingsystem.service.TransactionService;
import com.onlinebankingsystem.service.UserService;
import com.onlinebankingsystem.utils.Constants;
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/transaction")
public class TransactionController {
	
	@Autowired
	TransactionService transactionService;
	
	@Autowired
	UserService userService;
	
	@PostMapping("/withdraw")
	public ResponseEntity<Response> withdrawAmount(@RequestBody TransactionRequest transactionRequest) throws InsufficientBalanceException, InactiveAccountException, UserNotFoundException, AccountNotFoundException{
		Response response=new Response();
		transactionService.withdraw(transactionRequest);
		response.setCode(HttpStatus.OK.value());
		response.setMessage(Constants.TRANSACTION_COMPLTED);
        return ResponseEntity.ok(response);
		
		}
	
	@PostMapping("/deposite")
	public ResponseEntity<Response> depositeAmount(@RequestBody TransactionRequest transactionRequest) throws InactiveAccountException, UserNotFoundException, AccountNotFoundException {
		Response response=new Response();
		transactionService.deposite(transactionRequest);
		response.setCode(HttpStatus.OK.value());
		response.setMessage(Constants.DEPOSITE+""+Constants.TRANSACTION_COMPLTED);
        return ResponseEntity.ok(response);
		
		
		
	}
	@PostMapping("/transfer")
	public ResponseEntity<Response>  transferAmount(@RequestBody TransferRequest transferRequest) throws InactiveAccountException, InsufficientBalanceException, UserNotFoundException, AccountNotFoundException{
		Response response=new Response();
		transactionService.Transfer(transferRequest);
		response.setCode(HttpStatus.OK.value());
		response.setMessage(Constants.TRANSFER+""+Constants.TRANSACTION_COMPLTED);
        return ResponseEntity.ok(response);
		
	}
	
	@GetMapping("/getbalance/{userId}")
	public ResponseEntity<Response>  getBalance(@PathVariable Long userId) throws AccountNotFoundException, InsufficientBalanceException, InactiveAccountException{
		Response response=new Response();
		String validate=userService.getBalanceByuserId(userId);
		response.setMessage(validate);
		response.setCode(HttpStatus.OK.value());
        return ResponseEntity.ok(response);
		
		
	}
	}
	
	


