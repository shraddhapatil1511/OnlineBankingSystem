package com.onlinebankingsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.onlinebankingsystem.dto.Response;
import com.onlinebankingsystem.dto.UserRegistration;
import com.onlinebankingsystem.dto.ValidateUserDto;
import com.onlinebankingsystem.exception.DuplicateEmailException;
import com.onlinebankingsystem.exception.InvalidCredentialsException;
import com.onlinebankingsystem.exception.RegistrationException;
import com.onlinebankingsystem.exception.TransactionSystemException;
import com.onlinebankingsystem.exception.UserNotFoundException;
import com.onlinebankingsystem.model.User;
import com.onlinebankingsystem.repository.UserRepository;
import com.onlinebankingsystem.service.UserService;
import com.onlinebankingsystem.utils.Constants;
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/User")
public class UserController {
	
	
	@Autowired
	UserService userservice;

	
	
	@PostMapping("/register")
	public ResponseEntity<Response>  RegisterUser(@RequestBody UserRegistration userRegistration) throws  TransactionSystemException, DuplicateEmailException
	{
		
		Response response=new Response();
		userservice.registerUser(userRegistration);
		response.setCode(HttpStatus.OK.value());
		response.setMessage(Constants.USER_REGISTER_SUCESSFULLY);
			 return ResponseEntity.ok(response);
		
		
		
	}
	
	@PostMapping("/validateUser")
	public ResponseEntity<Response> validateUser(@RequestParam String username,@RequestParam String password  ) throws InvalidCredentialsException
	{
		Response response=new Response();
		  userservice.validateUser(username,password);
		   response.setCode(HttpStatus.OK.value());
		   response.setMessage(Constants.LOGIN_SUCCESSFULLY);
			   return ResponseEntity.ok(response);
		
	}
	


}
